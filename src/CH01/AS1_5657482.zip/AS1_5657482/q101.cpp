#include <iostream>

using namespace std;// namespace std;

int main(int argc, char *argv[])
{
    cout << "*************************************\n";
    cout << "Name : Hwang Doyun\n";
    cout << "ID : 5657482\n";
    cout << "Phone : 010-2798-8454\n";
    cout << "Department : computer engineering\n";
    cout << "Grade : 4th grade\n";
    cout << "*************************************\n";

    return 0;
}
