#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int num1, num2, total;

    num1 = 62;
    num2 = 99;

    total = num1+num2;
    cout<<total<<endl;
    
    return 0;
}
