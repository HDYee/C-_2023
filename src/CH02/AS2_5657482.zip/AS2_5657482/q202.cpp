#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
   
    float east_coast, total_sales, result;

    east_coast = 0.62;
    total_sales = 4.6;

    result = total_sales * east_coast;

    cout<<"$"<<result<<"million"<<endl;


    return 0;
}
